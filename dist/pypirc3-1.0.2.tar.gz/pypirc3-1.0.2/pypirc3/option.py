#!/usr/bin/env python
# -*- coding: utf-8 -*-

ACTION_CREATE = 'create'
ACTION_SHOW   = 'show'
